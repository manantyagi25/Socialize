package com.example.newlogin;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import static com.example.newlogin.MainActivity.databaseReference;
import static com.example.newlogin.MainActivity.user;

import java.util.ArrayList;

public class FriendsFragment extends Fragment {

    Button findNewFriends;
    ListView friendsList;
    ArrayList<String> userFriends;
//    CustomListAdapter_FriendsList customListAdapter_friendsList;
    ArrayAdapter<String> adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_friends, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("users").child(user.getUid());
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                String name = snapshot.child("firstName").getValue().toString();
                Log.i("User", name);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        userFriends = new ArrayList<>();
        userFriends.add("Rohaan");
        userFriends.add("Shantanu");
        userFriends.add("Vishal");
        userFriends.add("Bishal");

        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, userFriends);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        findNewFriends = view.findViewById(R.id.findNewFriends);
        friendsList = view.findViewById(R.id.friendsList);
        friendsList.setAdapter(adapter);


        friendsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                new AlertDialog.Builder(getContext())
                        .setTitle("Confirm Unfriend?")
                        .setMessage("Unfriending will remove this user from your friends list")
                        .setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getContext(), "User removed from your Friends", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();

                return false;
            }
        });

    }
}
