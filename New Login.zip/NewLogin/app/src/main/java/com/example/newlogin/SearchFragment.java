package com.example.newlogin;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import static com.example.newlogin.MainActivity.databaseReference;
import static com.example.newlogin.MainActivity.user;

public class SearchFragment extends Fragment {

    ListView searchList;
    ArrayList<String> foundUsers;
    ArrayList<String> names;
    ArrayAdapter<String> adapter;
    EditText searchET;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        foundUsers = new ArrayList<String>();
        names = new ArrayList<>();
        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, names);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        searchET = view.findViewById(R.id.searchET);
        searchList = view.findViewById(R.id.searchLV);

        searchList.setAdapter(adapter);

        searchET.requestFocus();
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(searchET, InputMethodManager.SHOW_IMPLICIT);

        searchList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.i("User Clicked", foundUsers.get(i));
                ViewAccountFragment viewAccountFragment = new ViewAccountFragment();
                Bundle args = new Bundle();
                args.putString(viewAccountFragment.UID, foundUsers.get(i));
                viewAccountFragment.setArguments(args);
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, viewAccountFragment).commit();
            }
        });



        searchET.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                foundUsers.clear();
                names.clear();
                adapter.notifyDataSetChanged();
                String entered = searchET.getText().toString().toLowerCase();

                if(entered.length() > 0)
                    queryUsers(entered);
                else {
                    names.clear();
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void queryUsers(final String entered) {

        databaseReference = FirebaseDatabase.getInstance().getReference().child("users");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    String uid = dataSnapshot.child("firstName").getValue().toString();

                    if (!uid.equals(FirebaseDatabase.getInstance().getReference().child("users").child(user.getUid()).child("firstName").toString())) {

                        Pattern pattern = Pattern.compile("^" + entered, Pattern.CASE_INSENSITIVE);
                        Matcher matcher = pattern.matcher(uid);
                        boolean isFound = matcher.find();
                        if (isFound) {
                            String fullName = dataSnapshot.child("firstName").getValue().toString() + " " + dataSnapshot.child("lastName").getValue().toString();
                            names.add(fullName);
                            foundUsers.add(dataSnapshot.getKey());
                            Log.i("User", fullName);
                        }
                    }
//                    Log.i("User", dataSnapshot.toString());
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        /*Query userQuery = databaseReference.orderByChild("firstName").equalTo(entered);
        userQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                Log.i("Datasnapshot", snapshot.toString());
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Log.i("Snapshot", dataSnapshot.getValue().toString());
                    Log.i("Found!", "Yes");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });*/

    }
}
