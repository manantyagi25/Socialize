package com.example.newlogin;

import androidx.constraintlayout.widget.ConstraintLayout;

public class Comments {

    public String commentText;
    public String commentBy;

    public String getCommentText() {
        return commentText;
    }

    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }

    public String getCommentBy() {
        return commentBy;
    }

    public void setCommentBy(String commentBy) {
        this.commentBy = commentBy;
    }

    public Comments() {
        this.commentText = "";
        this.commentBy = "";
    }

    public Comments(String commentText, String commentBy){
        this.commentText = commentText;
        this.commentBy = commentBy;
    }
}
