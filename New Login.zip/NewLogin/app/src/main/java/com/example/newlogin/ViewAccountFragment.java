package com.example.newlogin;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.File;
import java.io.FileOutputStream;

import static com.example.newlogin.MainActivity.databaseReference;
import static com.example.newlogin.MainActivity.user;


public class ViewAccountFragment extends Fragment {

    final static String UID = "UID";
    Bundle bundle;
    String searchedUID, fullName;
    TextView searchedUserName;
    ImageView userDP;
    Button addFriend, message;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_viewaccount, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        bundle = getArguments();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        searchedUserName = view.findViewById(R.id.searchedUserNameTV);
        userDP = view.findViewById(R.id.searchedUserDP);
        addFriend = view.findViewById(R.id.addFriendButton);
        message = view.findViewById(R.id.messageUserButton);



        searchedUID = bundle.getString(UID);
        databaseReference = FirebaseDatabase.getInstance().getReference().child("users").child(searchedUID);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                fullName = snapshot.child("firstName").getValue().toString() + " " + snapshot.child("lastName").getValue().toString();
                searchedUserName.setText(fullName);
                Log.i("Name", fullName);

                File path = new File(getContext().getExternalFilesDir(null).toString(), "/profilePics/");
                File pathToProfilePic = new File(path, searchedUID);
                Log.i("Path", pathToProfilePic.toString());

                if (pathToProfilePic.exists()) {
                    Log.i("File", "exists");
                    userDP.setImageBitmap(BitmapFactory.decodeFile(pathToProfilePic.toString()));
                } else {
                    Log.i("File", "not exists");
                    StorageReference reference = FirebaseStorage.getInstance().getReference();
                    reference.child(searchedUID).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Picasso.get().load(uri).into(userDP);

                            Target target = new Target() {
                            @Override
                            public void onBitmapLoaded(Bitmap bitmap1, Picasso.LoadedFrom from) {

                                BitmapDrawable drawable = (BitmapDrawable) userDP.getDrawable();
                                Bitmap bitmap = drawable.getBitmap();
                                try {
                                    File file = new File(getContext().getExternalFilesDir(null).toString());
                                    File myDir = new File(file, "profilePics");
                                    if (!myDir.exists())
                                        myDir.mkdirs();

                                    myDir = new File(myDir, searchedUID);
                                    FileOutputStream outputStream = new FileOutputStream(myDir);
                                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
                                    outputStream.flush();
                                    outputStream.close();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                            }

                            @Override
                            public void onPrepareLoad(Drawable placeHolderDrawable) {}
                        };

                        Picasso.get().load(uri).into(target);
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}
