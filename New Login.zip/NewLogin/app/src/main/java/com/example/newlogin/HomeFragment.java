package com.example.newlogin;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static com.example.newlogin.MainActivity.user;


public class HomeFragment extends Fragment {


    EditText post;
    Button postButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        post = view.findViewById(R.id.newPostET);
        postButton = view.findViewById(R.id.postButton);

        postButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = post.getText().toString();

                if(text.length() == 0)
                    Toast.makeText(getContext(), "Can't share empty posts!", Toast.LENGTH_SHORT).show();
                else{
                    Log.i("Post", text);
                    Posts posts = new Posts(text, user.getUid(), 0);
                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("users").child(user.getUid()).child("posts").push();
                    reference.setValue(posts);
                    Toast.makeText(getContext(), "Post shared!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
