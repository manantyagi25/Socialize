package com.example.newlogin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import static com.example.newlogin.MainActivity.auth;
import static com.example.newlogin.MainActivity.databaseReference;
import static com.example.newlogin.MainActivity.firebaseDatabase;
import static com.example.newlogin.MainActivity.preferences;
import static com.example.newlogin.MainActivity.storageReference;
import static com.example.newlogin.MainActivity.user;

public class AccountFragment extends Fragment {

    TextView nameTV;
    ListView accountSettingsLV;
    public static ImageView profilePic;
    ArrayList<String> settings;
    ArrayAdapter<String> adapter;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_account, container, false);

        return rootView;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        settings = new ArrayList<>();
        settings.add("Update your account data");
        settings.add("Logout");

        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, settings);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        nameTV = view.findViewById(R.id.nameTV);
        nameTV.setText(preferences.getString("name", ""));

        accountSettingsLV = view.findViewById(R.id.accountSettingsLV);
        accountSettingsLV.setAdapter(adapter);
        accountSettingsLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                doAction(i);
            }
        });


        /*profilePic = view.findViewById(R.id.profilePicIV);
        storageReference = FirebaseStorage.getInstance().getReference();
        storageReference.child("profilePics").child(user.getUid()).getDownloadUrl()
                .addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        profilePic.setImageURI(uri);
                    }
                });*/

        profilePic = view.findViewById(R.id.profilePicIV);
        profilePic.setImageResource(R.drawable.fb);

        File path = new File(getContext().getExternalFilesDir(null).toString(), "/profilePics/");
        File pathToProfilePic = new File(path, user.getUid());
        Log.i("Path", pathToProfilePic.toString());
        if(pathToProfilePic.exists()){
            Log.i("File", "exists");
            profilePic.setImageBitmap(BitmapFactory.decodeFile(pathToProfilePic.toString()));
        }
        else {
            Log.i("File", "not exists");
            storageReference = FirebaseStorage.getInstance().getReference();
            storageReference.child(user.getUid()).getDownloadUrl()
                    .addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            //                        profilePic.setImageBitmap(uri.getPath());
                            Picasso.get().load(uri).into(profilePic);

                                Target target = new Target() {
                                    @Override
                                    public void onBitmapLoaded(Bitmap bitmap1, Picasso.LoadedFrom from) {

                                        BitmapDrawable drawable = (BitmapDrawable) profilePic.getDrawable();
                                        Bitmap bitmap = drawable.getBitmap();
                                        try {
                                            File file = new File(getContext().getExternalFilesDir(null).toString());
                                            File myDir = new File(file, "profilePics");
                                            if (!myDir.exists())
                                                myDir.mkdirs();

                                            String picUID = user.getUid();
                                            myDir = new File(myDir, picUID);
                                            FileOutputStream outputStream = new FileOutputStream(myDir);
                                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
                                            outputStream.flush();
                                            outputStream.close();
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                @Override
                                public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                                }

                                @Override
                                public void onPrepareLoad(Drawable placeHolderDrawable) {}
                            };

                            Picasso.get().load(uri).into(target);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            profilePic.setImageResource(R.drawable.fb);
                            Toast.makeText(getContext(), "Error downloading profile pic!", Toast.LENGTH_SHORT).show();
                        }
                    });
        }

    }

    public void logOutUser(){

        new AlertDialog.Builder(getContext())
                .setTitle("Confirm logout?")
                .setMessage("This would sign you out of this device until you log in back")
                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        auth.getInstance().signOut();
                        Intent intent = new Intent(getContext(), LoginActivity.class);

                        //To make sure going back is not possible
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void doAction(int i){
        if(i ==0)
            Toast.makeText(getContext(), "This service is not available now", Toast.LENGTH_SHORT).show();
        else if(i == 1)
            logOutUser();
    }

}
