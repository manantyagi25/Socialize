package com.example.newlogin;

public class Friends {

    public String friendID;
    public String friendName;

    public String getfriendID() {
        return friendID;
    }

    public String getFriendName(){
        return friendName;
    }

    public void setfriendID(String friendID) {
        this.friendID = friendID;
    }

    public void setFriendName(String friendName){
        this.friendName = friendName;
    }

    public Friends(){
        this.friendID = "";
        this.friendName = "";
    }

    public Friends(String friendID, String friendName){
        this.friendID = friendID;
        this.friendName = friendName;
    }
}
