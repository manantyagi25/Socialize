package com.example.newlogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.UUID;

import static com.example.newlogin.AccountFragment.profilePic;

public class MainActivity extends AppCompatActivity {

    static public SharedPreferences preferences;
    static public FirebaseAuth auth;
    static public FirebaseApp app;
    static public FirebaseStorage storage;
    static public StorageReference storageReference;
    static public DatabaseReference databaseReference;
    static public DatabaseReference databaseReference1;
    static public FirebaseDatabase firebaseDatabase;
    static public FirebaseUser user;
    static public BottomNavigationView bottomNavigationView;
    private ArrayList<String> friends;

    private final int PICK_IMAGE_REQUEST = 71;
    private Uri filePath;
    private AlertDialog deleteDialog;
    private Fragment selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(savedInstanceState != null)
            getSupportFragmentManager().findFragmentByTag("myFragment").setRetainInstance(true);
        else {
            FirebaseApp.initializeApp(this);
            setContentView(R.layout.activity_main);

            auth = FirebaseAuth.getInstance();
            preferences = getSharedPreferences("com.example.newlogin", MODE_PRIVATE);

            user = FirebaseAuth.getInstance().getCurrentUser();
            firebaseDatabase = FirebaseDatabase.getInstance();

            storage = FirebaseStorage.getInstance();
            storageReference = storage.getReference();

            /*friends = new ArrayList<>();
            *//*friends.add("Rohaan");
            friends.add("Shantanu");
            friends.add("Vishal");
            friends.add("Bishal");*//*

            databaseReference1 = firebaseDatabase.getReference().child("users").child(user.getUid()).child("friends");
            databaseReference1.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    friends = (ArrayList<String>) snapshot.getValue();
                    for(int i = 0 ; i<friends.size() ; ++i)
                        Log.i("Friends", friends.toString());
//                        Log.i("Friend" + i , friends.get(i));
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            friends.add("Prashant");
            Log.i("Added", "Prashant");
            databaseReference1.setValue(friends);
*/

//            Log.i("Friends", "Added");

            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
            bottomNavigationView = findViewById(R.id.navBar);
            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    selected = null;

                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            selected = new HomeFragment();
                            break;

                        case R.id.nav_search:
                            selected = new SearchFragment();
                            break;

                        case R.id.nav_friends:
                            selected = new FriendsFragment();
                            break;

                        case R.id.nav_account:
                            selected = new AccountFragment();
                            break;

                        case R.id.nav_settings:
                            selected = new SettingsFragment();
                            break;
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selected).commit();
                    return true;
                }
            });
        }

        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser != null) {

            //Toast.makeText(getApplicationContext(), "Welcome Back!", Toast.LENGTH_SHORT).show();
            databaseReference = firebaseDatabase.getReference().child("users").child(user.getUid());
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String name = snapshot.child("firstName").getValue().toString();
                    name = name + " " + snapshot.child("lastName").getValue().toString();
                    preferences.edit().putString("name", name).apply();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        }
        else {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
        }
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
//        super.onSaveInstanceState(outState, outPersistentState);

        FragmentManager manager = getSupportFragmentManager();
        manager.putFragment(outState, "myFragmentName", selected);
    }

    @Override
    protected void onRestoreInstanceState(Bundle inState) {
        instantiateFragments(inState);
    }

    private void instantiateFragments(Bundle inState) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();

        if (inState != null) {
            selected = (AccountFragment) manager.getFragment(inState, "myFragmentName");
        } else {
            selected = new AccountFragment();
            transaction.add(R.id.fragment_container, selected, "myFragmentName");
            transaction.commit();
        }
    }

    public void imageChangerDialog(View view){

        deleteDialog = new AlertDialog.Builder(this)
                .setView(R.layout.image_changer_dialog)
                .show();
    }

    public void imageChanger(View view){
        if(view.getTag().toString().equals("add")){
            chooseImageAndUpload();
        }
        else if (view.getTag().toString().equals("remove")){
            StorageReference deleteImage = storageReference.child(user.getUid());
            deleteImage.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    profilePic.setImageResource(R.drawable.fb);
                    Toast.makeText(getApplicationContext(), "Image Deleted Successfully", Toast.LENGTH_SHORT).show();

                }
            });
        }
        deleteDialog.dismiss();
    }

    private void chooseImageAndUpload(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                profilePic.setImageBitmap(bitmap);

                if(filePath != null)
                {
                    final ProgressDialog progressDialog = new ProgressDialog(this);
                    progressDialog.setTitle("Uploading...");
                    progressDialog.show();

                    StorageReference ref = storageReference.child(user.getUid());
                    ref.putFile(filePath)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    progressDialog.dismiss();
                                    Toast.makeText(MainActivity.this, "Uploaded", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    progressDialog.dismiss();
                                    Toast.makeText(MainActivity.this, "Failed "+e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                    double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot
                                            .getTotalByteCount());
                                    progressDialog.setMessage("Uploaded "+(int)progress+"%");
                                }
                            });
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

}