package com.example.newlogin;


public class Posts {

    public String postText;
    public String postBy;
    public Integer likes;

    public String getPostText() {
        return postText;
    }

    public void setPostText(String postText) {
        this.postText = postText;
    }

    public String getPostBy() {
        return postBy;
    }

    public void setPostBy(String postBy) {
        this.postBy = postBy;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Posts(){
        this.postText = "";
        this.postBy = "";
        this.likes = 0;
    }

    public Posts(String postText, String postBy, Integer likes){
        this.postText = postText;
        this.postBy = postBy;
        this.likes = likes;
    }
}
